﻿using System;
namespace oops
{


    public class Dog
    {
        String name;
        String breed;
        int age;


        public Dog(String name, String breed, int age)
        {
            this.name = name;
            this.breed = breed;
            this.age = age;

        }
        public String GetName()
        {
            return name;
        }
        public String GetBreed()
        {
            return breed;
        }
        public int GetAge()
        {

            return age;
        }
        public String ToString()
        {
            return ("Hi my name is " + this.GetName());
        }
        public static void Main(String[] args)
        {
            Dog puppy = new Dog("puppy", "Pappilon", 5);
            Console.WriteLine(puppy.ToString());
        }
    }
}
