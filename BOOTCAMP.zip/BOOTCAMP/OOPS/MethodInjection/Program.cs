﻿using System;
namespace MethodInjection
{


    public interface I3
    {
        void Demo3();
    }


    public class ServiceClass : I3
    {
        public void Demo3()
        {
            Console.WriteLine("Demo3 Method Overriding - Service Class.");
        }
    }


    public class ClientClass
    {
        private I3 _i3;
        public void ClientClassMethod(I3 _i3)
        {
            this._i3 = _i3;
            Console.WriteLine("Client Class Method Statement Called.");
            this._i3.Demo3();
        }


        class Program
        {
            static void Main(string[] args)
            {
                ClientClass CCLS = new ClientClass();

                CCLS.ClientClassMethod(new ServiceClass());

                Console.ReadKey();
            }
        }
    }
}