﻿using System;
namespace ClassObject
{
    class Dog
    {
        string breed;
        public void bark()
        {
            Console.WriteLine("Bark Bark");
        }
        static void Main(string[] args)
        {
            Dog bullDog=new Dog();
            bullDog.bark();
            Console.WriteLine();
        }
    }
}
