﻿using System;
namespace Interface
{
    interface IAnimal
    {
        void animalSound();
    }
    class Pig:IAnimal
    {
        public void animalSound()
        {
            Console.WriteLine("The animal is making noise");
        }
        class Program
        {
            static void Main(String[] args)
            {
                Pig myPig=new Pig();
                myPig.animalSound();
            }
        }
    }
}
