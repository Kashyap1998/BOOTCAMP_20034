﻿using System;
namespace Abstraction
{
    abstract class Animal
    {
        public abstract void animalSound();

        public void sleep()
        {
            Console.WriteLine("Animal is sleeping");
        }
        class Pig : Animal
        {
            public override void animalSound()
            {
                Console.WriteLine("Animal makes sound");
            }
        }
        class Program
        {
            static void Main(String[] args)
            {
                Pig myPig = new Pig();
                myPig.animalSound();
                myPig.sleep();
            }

        }
    }
}