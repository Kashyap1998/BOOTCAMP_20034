﻿using System;
namespace DependencyInjectionDemo
{
    public interface I1
    {
        void Demo();
    }
    class child1 : I1
    {
        public void Demo()
        {
            Console.WriteLine("Demo function called of child1 class-Constructor injection");


        }
    }
    class child2 : I1
    {
        public void Demo()
        {
            Console.WriteLine("Demo Function Called of Child2 Class-Constructor Injection.");

        }
        public class ConstructorInjection
        {
            private I1 _i1;


            public ConstructorInjection(I1 _i1)
            {

                this._i1 = _i1;
            }
            public void Demo()
            {
                _i1.Demo();
            }
        }
        class program
        {
            static void Main(string[] args)
            {
                ConstructorInjection cs = null;
                cs = new ConstructorInjection(new child1());
                cs.Demo();
                cs = new ConstructorInjection(new child2());
                cs.Demo();
                Console.ReadKey();
            }
        }

    }
}
