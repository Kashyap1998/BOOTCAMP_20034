﻿using System;
namespace PropertyInjection
{
    public interface I2
    {
        void DemoPropertyInjection(string message);
    }

    class LogWriterClass : I2
    {
        public void DemoPropertyInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass - Property Injection.");
        }
    }
    class LogWriterClass2 : I2
    {
        public void DemoPropertyInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass2 - Property Injection.");
        }
    }
    class PropertyInjectionClass
    {
        I2 _i2 = null;
        public void DemoPropertyInjectionFunctionOfClass(I2 _i2, string messages)
        {
            this._i2 = _i2;
            _i2.DemoPropertyInjection(messages);
        }
        class Program
        {
            static void Main(string[] args)
            {

                PropertyInjectionClass PIC = new PropertyInjectionClass();

                // DemoPropertyInjectionFunctionOfClass() Method Called by using PropertyInjectionClass Object & LogWritterClass Passed as an Object + Message Property Value Passed.
                PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass(), "Message - Property Value Passed.");
                PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass2(), "Message - Property Value Passed.");
                Console.ReadKey();
            }
        }
    }
}


