﻿using System;
namespace oops
{
    class Employee
    {
        public string department;
       
    }

    class program
    {
        public static void Main(string[] args)
        {
            Employee Shivam = new Employee();
            Shivam.department = "Physics";
            Console.WriteLine(Shivam.department);
        }
    }
    

}