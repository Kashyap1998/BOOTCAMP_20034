﻿using System;
namespace oops
{
    class Abc
    {
        public void run()
        {
            Console.WriteLine("no parameter,no return");
        }
        public void run(int a)
        {
            Console.WriteLine("with return,with parameter");
        }
        public void run(int a, char c)
        {
            Console.WriteLine("With different parameter");
        }
    }
    class Program
    {
        public static void Main(String[] args)
        {
            Abc xyz = new Abc();
            xyz.run();
            xyz.run(4);
            xyz.run(4, 'c');
        }





    }
}
