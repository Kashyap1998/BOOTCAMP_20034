﻿using System;
namespace mo
{
    class Animal
    {
        public void animalSound()
        {
            Console.WriteLine("Animal makes sound");
        }

    }
    class Pig : Animal
    {
        public void animalSound()
        {
            Console.WriteLine("The pig says:wee wee");
        }
    }
    class Dog : Animal
    {
        public void animalSound()
        {
            Console.WriteLine("The dog says:BOW BOW");
        }
    }
    class Program
    {
        static void Main(String[] args)
        {
            Animal myAnimal = new Animal();
            Animal myPig = new Animal();
            Animal myDog = new Animal();
            myAnimal.animalSound();
            myPig.animalSound();
            myDog.animalSound();
        }
    }
}
